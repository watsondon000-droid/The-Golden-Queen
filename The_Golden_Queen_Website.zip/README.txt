THE GOLDEN QUEEN — RESTAURANT WEBSITE
======================================

PROJECT CONTENTS
- index.html   Home / landing page
- menu.html    Food menu with six meal cards
- order.html   Customer order form
- styles.css   Shared responsive styling
- script.js    Mobile navigation and client-side form validation

HOW TO RUN
1. Extract the ZIP file into a folder.
2. Open index.html in a modern web browser.
3. Use the navigation links to visit Menu and Order Form.

EDIT BEFORE SUBMISSION
- Replace "Your Name" in the footer of index.html, menu.html and order.html with your actual name.
- The menu uses the six dishes visible in the assignment notes: Chicken, Fish, Rice, Matooke, Beef and Chips.
- Food and hero photographs load from Unsplash and therefore require an internet connection.
- The order form validates required name, gender, meal and table number fields. Name is limited to 50 characters; table number is restricted to 1–12.

IMPORTANT NOTE ABOUT ORDER SUBMISSION
This is a front-end coursework demonstration. Submitting the form displays a confirmation in the browser; it does not send orders to a restaurant server or database. A backend service would be required for live order processing.

QR CODE
After the website is uploaded to a public web host, create a QR code pointing to its public index.html address. A QR code pointing to a local computer file will not work for customers.

DESIGN REQUIREMENTS INCLUDED
- Shared header and footer on all pages
- Header background #e0dede and requested box shadow
- Business name at top left, logo mark at top right
- Navigation hover effects and page links
- Menu heading and centered, rounded food cards with left-to-right linear gradients
- Responsive layout for desktop and mobile
- Required order form controls, radio buttons, checkboxes and submit button
