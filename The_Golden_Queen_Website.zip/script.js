// Shared navigation and order form behaviour
document.addEventListener("DOMContentLoaded", () => {
  const year = document.querySelector("[data-year]");
  if (year) year.textContent = new Date().getFullYear();

  const toggle = document.querySelector(".menu-toggle");
  const nav = document.querySelector(".main-nav");
  if (toggle && nav) {
    toggle.addEventListener("click", () => {
      const open = nav.classList.toggle("open");
      toggle.setAttribute("aria-expanded", String(open));
      toggle.textContent = open ? "×" : "☰";
    });
  }

  const form = document.getElementById("orderForm");
  if (form) {
    const table = document.getElementById("tableNumber");
    table.addEventListener("input", () => {
      if (table.value && (Number(table.value) < 1 || Number(table.value) > 12)) {
        table.setCustomValidity("Please enter a table number from 1 to 12.");
      } else {
        table.setCustomValidity("");
      }
    });
    form.addEventListener("submit", (event) => {
      event.preventDefault();
      if (!form.reportValidity()) return;
      const data = new FormData(form);
      const drinks = data.getAll("drinks");
      const message = document.getElementById("formMessage");
      message.textContent = `Thank you, ${data.get("customerName")}! Your ${data.get("meal")} order for table ${data.get("tableNumber")} has been recorded in this demo. Drinks: ${drinks.length ? drinks.join(", ") : "None"}.`;
      form.reset();
      table.setCustomValidity("");
    });
  }
});
